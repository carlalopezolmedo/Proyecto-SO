﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace ClienteSO
{
    public partial class Form1 : Form
    {
        private TcpClient clienteSocket; // Cliente para la conexión al servidor
        private NetworkStream serverstream; // Flujo de datos entre cliente y servidor

        public Form1()
        {
            InitializeComponent();

            try
            {
                clienteSocket = new TcpClient();
                clienteSocket.Connect("127.0.0.1", 9050); // Cambiar IP si el servidor está en otra máquina
                serverstream = clienteSocket.GetStream();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al conectar con el servidor: {ex.Message}");
            }

            label1.Visible = false;
            textBox2.Visible = false;
            button3.Visible = false;
            button2.Visible = false;

           
        }

        // Función para enviar datos al servidor
        private void SendRequest(string request)
        {
            if (clienteSocket == null || !clienteSocket.Connected)
            {
                MessageBox.Show("No hay conexión con el servidor.");
                return;
            }

            try
            {
                byte[] outStream = Encoding.ASCII.GetBytes(request);
                serverstream.Write(outStream, 0, outStream.Length);
                serverstream.Flush();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al enviar la solicitud: {ex.Message}");
            }
        }

        // Función para recibir la respuesta del servidor
        private string ReceiveResponse()
        {
            try
            {
                byte[] inStream = new byte[512];
                int bytesRead = serverstream.Read(inStream, 0, inStream.Length);
                if (bytesRead == 0)
                    throw new Exception("No se recibió respuesta del servidor.");

                return Encoding.ASCII.GetString(inStream, 0, bytesRead);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al recibir la respuesta: {ex.Message}");
                return string.Empty;
            }
        }
        // Evento para el campo de texto de nombre de usuario (cuando se presiona Enter)
        private void txtUsername_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string usuario = label2.Text.Trim(); ;

                if (string.IsNullOrEmpty(usuario))
                {
                    MessageBox.Show("Por favor, ingresa un nombre de usuario.");
                    return;
                }

                // Enviar petición de consulta al servidor
                string request = $"3/{usuario}";
                SendRequest(request);

                // Recibir respuesta del servidor
                string serverResponse = ReceiveResponse();

                if (string.IsNullOrEmpty(serverResponse)) return;

                if (serverResponse.Contains("Usuario encontrado"))
                {
                    // Si el usuario está registrado, mostramos el campo de contraseña y el botón de iniciar sesión
                    label1.Visible = true;
                    textBox2.Visible = true;
                    button3.Visible = true; // Mostrar botón de Iniciar Sesión
                    button2.Visible = false; // Ocultar botón de Registro
                    MessageBox.Show("Usuario encontrado. Por favor, ingrese su contraseña para iniciar sesión.");
                }
                else
                {
                    // Si el usuario no está registrado, habilitamos el registro
                    MessageBox.Show("Usuario no encontrado. Puedes registrarte.");
                    label1.Visible = true; // Mostrar el campo de contraseña
                    textBox2.Visible = true; // Mostrar el campo de contraseña
                    button3.Visible = false; // Ocultar botón de Iniciar Sesión
                    button2.Visible = true; // Mostrar botón de Registro
                }
            }
        }

        // Evento para el botón de "Registro"
        private void Registrarse_Click(object sender, EventArgs e)
        {
            string usuario = label2.Text.Trim(); ;
            string contraseña = label1.Text.Trim(); ;

            if (string.IsNullOrEmpty(usuario) || string.IsNullOrEmpty(contraseña))
            {
                MessageBox.Show("Por favor, ingresa un nombre de usuario y una contraseña.");
                return;
            }

            // Enviar petición de registro al servidor
            string request = $"1/{usuario}/{contraseña}";
            SendRequest(request);

            // Recibir respuesta del servidor
            string serverResponse = ReceiveResponse();

            if (string.IsNullOrEmpty(serverResponse)) return;

            if (serverResponse.Contains("Registro exitoso"))
            {
                MessageBox.Show("Registro exitoso. Ahora puedes iniciar sesión.");
                label1.Visible = true; // Mostrar el campo de contraseña
                textBox2.Visible = true; // Mostrar el campo de contraseña
                button3.Visible = true; // Mostrar botón de Iniciar Sesión
                button2.Visible = false; // Ocultar botón de Registro
            }
            else
            {
                MessageBox.Show("Error en el registro.");
            }
        }
        // Evento para finalizar el inicio de sesión después de ingresar la contraseña
        private void InicioSesion_Click(object sender, EventArgs e)
        {
            string usuario = label2.Text.Trim(); ;
            string contraseña = label1.Text.Trim(); ;

            if (string.IsNullOrEmpty(usuario) || string.IsNullOrEmpty(contraseña))
            {
                MessageBox.Show("Por favor, ingresa un nombre de usuario y una contraseña.");
                return;
            }
            // Enviar petición de inicio de sesión al servidor
            string request = $"2/{usuario}/{contraseña}";
            SendRequest(request);

            // Recibir respuesta del servidor
            string serverResponse = ReceiveResponse();

            if (string.IsNullOrEmpty(serverResponse)) return;

            if (serverResponse.Contains("Inicio de sesión correcto"))
            {
                MessageBox.Show("Inicio de sesión exitoso.");
            }
            else
            {
                MessageBox.Show("Error en el inicio de sesión. Verifica tu nombre de usuario o contraseña.");
            }
        }
        

        // Función para cerrar la conexión del cliente al salir de la aplicación
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (serverstream != null)
                    serverstream.Close();

                if (clienteSocket != null && clienteSocket.Connected)
                    clienteSocket.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cerrar la conexión: {ex.Message}");
            }
        }


    }
}

